﻿using System.ComponentModel.DataAnnotations;

namespace MYF_PROJECT.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public int ShippingId { get; set; }
        public string  Username { get; set; }
        
    }
}
