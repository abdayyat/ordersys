﻿using Microsoft.EntityFrameworkCore;
using MYF_PROJECT.Models;
namespace MYF_PROJECT.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<ShippingDetail> ShippingDetails { get; set; }
        public DbSet<PaymentDetail> PaymentDetails { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PaymentDetail>()
                .HasKey(p => p.PaymentId);

            modelBuilder.Entity<Category>()
                .HasKey(p => p.CategoryId);

            modelBuilder.Entity<Order>()
                .HasKey(p => p.OrderId);

            modelBuilder.Entity<OrderItem>()
                .HasKey(p => p.OrderItemId);

            modelBuilder.Entity<Product>()
                .HasKey(p => p.ProductId);

            modelBuilder.Entity<ShippingDetail>()
                .HasKey(p => p.ShippingDetailId);
        }


    }
}
